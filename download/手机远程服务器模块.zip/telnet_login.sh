#!/data/adb/modules/hyx-logoin/busybox sh
export LANG=C.UTF-8
export LC_ALL=C.UTF-8
cd /storage/emulated/0
exec /data/adb/modules/hyx-logoin/busybox sh