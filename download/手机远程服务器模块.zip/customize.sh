#!/system/bin/sh
ui_print "- 正在检测CPU架构"

rm -f "$MODPATH/busybox"
if [ "$ARCH" = "arm64" ] || [ "$IS64BIT" = true ]; then
    mv -f "$MODPATH/busybox64" "$MODPATH/busybox"
else
    mv -f "$MODPATH/busybox32" "$MODPATH/busybox"
fi
rm -f "$MODPATH/busybox32"
rm -f "$MODPATH/busybox64"

chmod 0755 "$MODPATH/busybox"
chmod 0755 "$MODPATH/service.sh"
chmod 0755 "$MODPATH/action.sh"
chmod 0755 "$MODPATH/telnet_login.sh"
chmod 0644 "$MODPATH/inetd.conf"

chown 0:0 "$MODPATH/busybox"
chown 0:0 "$MODPATH/service.sh"
chown 0:0 "$MODPATH/action.sh"
chown 0:0 "$MODPATH/telnet_login.sh"
chown 0:0 "$MODPATH/inetd.conf"

ui_print "模块安装完成，重启后生效"
ui_print "警告：该模块将向局域网开放无密码root读写权限，非必要请关闭"
ui_print "如因本模块导致数据泄露作者概不负责"
