#!/system/bin/sh
ui_print "依赖: 需安装 KernelSU meta-overlayfs"
ui_print "- 正在检测 CPU 架构"
ARCH_DIR="arm32"
if [ "$ARCH" = "arm64" ] || [ "$IS64BIT" = true ]; then
    ARCH_DIR="arm64"
fi
mv -f "$MODPATH/bin/$ARCH_DIR/"* "$MODPATH/bin/" 2>/dev/null
rm -rf "$MODPATH/bin/arm64" "$MODPATH/bin/arm32"
chmod 0755 "$MODPATH/bin/"* 2>/dev/null
chmod 0755 "$MODPATH/service.sh" "$MODPATH/action.sh"
chmod 0644 "$MODPATH/inetd.conf" "$MODPATH/passwd.conf" "$MODPATH/module.prop"
chmod 0644 "$MODPATH/system/etc/passwd" "$MODPATH/system/etc/group" "$MODPATH/system/etc/shells" 2>/dev/null
chown 0:0 "$MODPATH" -R 2>/dev/null
ui_print "默认登录用户:hyx"
ui_print "默认密码:12345678，请前往/data/adb/modules/hyx-login/passwd.conf修改密码，修改密码后请运行更新密码.sh使密码生效。"
ui_print "模块安装完成，重启后生效"
ui_print "警告:该模块会向局域网开放root端口，非必要请关闭"
ui_print "如因本模块导致数据泄露作者概不负责"