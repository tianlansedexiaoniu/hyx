#!/system/bin/sh
MODDIR=${0%/*}
BB="$MODDIR/bin/busybox"
PROP="${MODDIR}/module.prop"
if $BB ps | $BB grep -q "[i]netd ${MODDIR}/inetd.conf"; then
    $BB pkill -f "inetd" 2>/dev/null
    $BB sed -i "s/\\\\n已启用🟢//g" "$PROP"
    $BB sed -i "s/\\\\n已关闭🔴//g" "$PROP"
    $BB sed -i "s/^description=.*/&\\\\n已关闭🔴/" "$PROP"
else
    killall -9 inetd 2>/dev/null
    sh "$MODDIR/service.sh"
fi