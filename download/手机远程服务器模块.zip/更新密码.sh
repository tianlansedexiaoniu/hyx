#!/system/bin/sh
MODDIR=${0%/*}
BIN="$MODDIR/bin"
BB="$BIN/busybox"
PASSFILE="$MODDIR/passwd.conf"
PWFILE="$MODDIR/system/etc/passwd"
PWD=$($BB sed -e 's/#.*//' -e '/^[[:space:]]*$/d' "$PASSFILE" | $BB head -1)
PWD="${PWD#password=}"
HASH=$("$BIN/mkpasswd" -m 1 "$PWD")
$BB sed -i "s#^hyx:[^:]*:#hyx:${HASH}:#" "$PWFILE"
umount /etc/passwd 2>/dev/null
mount -o bind "$PWFILE" /etc/passwd
killall -9 inetd 2>/dev/null
$BB inetd "$MODDIR/inetd.conf"