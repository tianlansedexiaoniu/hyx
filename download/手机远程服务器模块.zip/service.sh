#!/system/bin/sh
MODDIR=${0%/*}
BIN="$MODDIR/bin"
BB="$BIN/busybox"
PROP="${MODDIR}/module.prop"
DBDIR="${MODDIR}/etc/dropbear"
PASSFILE="${MODDIR}/passwd.conf"

chmod 0755 "$BIN"/* 2>/dev/null
chmod 0644 "$MODDIR/inetd.conf" "$MODDIR/passwd.conf" 2>/dev/null

mkdir -p "$DBDIR"
for t in rsa ecdsa ed25519; do
    if [ ! -s "$DBDIR/dropbear_${t}_host_key" ]; then
        "$BIN/dropbearkey" -t "$t" -f "$DBDIR/dropbear_${t}_host_key" 2>/dev/null
    fi
done

mkdir -p "$MODDIR/system/etc"

PASSWORD=$($BB sed -e 's/[[:space:]]*#.*//' -e 's/[[:space:]]*$//' -e '/^[[:space:]]*$/d' "$PASSFILE" 2>/dev/null | $BB head -1)
PASSWORD="${PASSWORD#password=}"

if [ -n "$PASSWORD" ]; then
    HASH=$("$BIN/mkpasswd" -m 6 "$PASSWORD" 2>/dev/null)
    [ -z "$HASH" ] && HASH=$("$BIN/mkpasswd" -m 1 "$PASSWORD" 2>/dev/null)
    if [ -n "$HASH" ]; then
        $BB sed -i "s|^hyx:[^:]*:|hyx:$HASH:|" "$MODDIR/system/etc/passwd"
    fi
fi

chmod 0644 "$MODDIR/system/etc/passwd"

for f in passwd group shells; do
    src="$MODDIR/system/etc/$f"
    [ -f "$src" ] || continue
    case "$f" in
        passwd) marker='^hyx:' ;;
        group)   marker='^root:' ;;
        shells)  marker='/system/bin/sh' ;;
    esac
    if ! $BB grep -q "$marker" "/etc/$f" 2>/dev/null; then
        mount -o bind "$src" "/etc/$f" 2>/dev/null
    fi
done

killall -9 inetd 2>/dev/null
$BB inetd "${MODDIR}/inetd.conf"

$BB sed -i "s/\\\\n已启用🟢//g" "$PROP"
$BB sed -i "s/\\\\n已关闭🔴//g" "$PROP"
$BB sed -i "s/^description=.*/&\\\\n已启用🟢/" "$PROP"