#!/system/bin/sh
MODDIR=${0%/*}
chmod 0755 $MODDIR/busybox
chmod 0755 $MODDIR/service.sh
chmod 0755 $MODDIR/action.sh
chmod 0755 $MODDIR/telnet_login.sh
chmod 0644 $MODDIR/inetd.conf
chown 0:0 $MODDIR/busybox
chown 0:0 $MODDIR/service.sh
chown 0:0 $MODDIR/action.sh
chown 0:0 $MODDIR/telnet_login.sh
chown 0:0 $MODDIR/inetd.conf
BB=/data/adb/modules/hyx-logoin/busybox
PROP="${MODDIR}/module.prop"
killall -9 inetd 2>/dev/null
$BB inetd "${MODDIR}/inetd.conf"
$BB sed -i "s/\\\\n已启用🟢//g" "$PROP"
$BB sed -i "s/\\\\n已关闭🔴//g" "$PROP"
$BB sed -i "s/^description=.*/&\\\\n已启用🟢/" "$PROP"